#include "MainGame.h"
#include "macroFunction.h"
#include "Image.h"
#include "SceneManager.h"

MainGame* MainGame::Instance = 0;

HRESULT MainGame::Init()
{
	hdc = GetDC(g_hWnd);

	backBuffer = new Image();
	backBuffer->Init(WINSIZE_X, WINSIZE_Y);

	KeyManager::GetSingleton()->Init();
	ImageMgr::GetSingleton()->Init();
	TimeManager::GetSingleton()->Init();

	sceneMgr = new SceneManager();
	sceneMgr->Init();

	isInit = true;
	return S_OK;
}

void MainGame::Release()
{
	sceneMgr->Release();
	SAFE_DELETE(sceneMgr);

	KeyManager::GetSingleton()->Release();
	KeyManager::GetSingleton()->ReleaseSingleton();

	ImageMgr::GetSingleton()->Release();
	ImageMgr::GetSingleton()->ReleaseSingleton();

	TimeManager::GetSingleton()->Release();
	TimeManager::GetSingleton()->ReleaseSingleton();

	backBuffer->Release();
	delete backBuffer;

	ReleaseDC(g_hWnd, hdc);
}


void MainGame::Update()
{
	if (sceneMgr)
	{
		sceneMgr->Update();
	}

	InvalidateRect(g_hWnd, NULL, false); //backbuffer�� �־��� �Ŀ��� false�� ������ֱ�
}

void MainGame::Render()
{
	sceneMgr->Render(backBuffer->GetMemDC());
	TimeManager::GetSingleton()->Render(backBuffer->GetMemDC());
	backBuffer->Render(hdc, 0, 0);
}

LRESULT MainGame::MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch (iMessage)
	{
	
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);

		EndPaint(hWnd, &ps);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		}

		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}



MainGame::MainGame()
	: isInit(false)
{
}


MainGame::~MainGame()
{
}
