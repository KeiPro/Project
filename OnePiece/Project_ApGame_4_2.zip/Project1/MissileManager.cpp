#include "MissileManager.h"
#include "Missile.h"
#include "Battle.h"
#include "Object.h"
#include "EnemyManager.h"
#include "PlayerMissile.h"
#include "EnemyMissile.h"
#include "Player.h"

HRESULT MissileManager::Init(bool isEnemy)
{
	if (!isEnemy)
	{
		vecPlayerMissiles.reserve(100);
		for (int i = 0; i < 100; i++)
		{
			PlayerMissile* P_missile = new PlayerMissile();
			P_missile->Init();
			StP_Missiles.push(P_missile);
		}
	}
	else
	{
		vecEnemyMissiles.reserve(100);
		for (int i = 0; i < 100; i++)
		{
			EnemyMissile* E_missile = new EnemyMissile();
			E_missile->Init();
			StE_Missiles.push(E_missile);
		}

		int a = StE_Missiles.size();
	}
	
	isEnemy = false;
	object = nullptr;

	RandAngle = rand() % 10;
	return S_OK;
}

void MissileManager::Release(bool isEnemy)
{
	if (!isEnemy)
	{
		for (auto& it : vecPlayerMissiles)
		{
			it->Release();
			SAFE_DELETE(it);
		}
		vecPlayerMissiles.clear();

		for (int i = 0; i < 100; i++)
		{
			if (StP_Missiles.size() > 0)
			{
				StP_Missiles.pop();
				if (StP_Missiles.empty())
					break;
			}
		}
	}
	else
	{
		for (auto& it : vecEnemyMissiles)
		{
			it->Release();
			SAFE_DELETE(it);
		}
		vecEnemyMissiles.clear();

		for (int i = 0; i < 100; i++)
		{
			if (StE_Missiles.size() > 0)
			{
				StE_Missiles.pop();
				if (StE_Missiles.empty())
					break;
			}
		}
	}
}

void MissileManager::Update()
{
	if ((vecPlayerMissiles.size()) > 0)
	{
		for (vector<PlayerMissile*>::iterator p = vecPlayerMissiles.begin(); p != vecPlayerMissiles.end(); p++)
		{
			(*p)->Update();
			if ((*p)->GetPos().x >= WINSIZE_X + 100 || (*p)->GetPos().y <= 0 - 100 || (*p)->GetPos().y >= WINSIZE_Y + 100
				|| Battle::instance->GetEnemyMgr()->Onhit((*p)->GetPos()))
			{
				(*p)->SetIsFire(false);
				StP_Missiles.push((*p));
				p = vecPlayerMissiles.erase(p);
				if (p == vecPlayerMissiles.end())
					break;
			}
		}
	}

	if ((vecEnemyMissiles.size()) > 0)
	{
		for (vector<EnemyMissile*>::iterator e = vecEnemyMissiles.begin(); e != vecEnemyMissiles.end(); e++)
		{
			(*e)->Update();
			if ((*e)->GetPos().x <= 0-100 || (*e)->GetPos().x >= WINSIZE_X+100 || (*e)->GetPos().y <= 0-100 || (*e)->GetPos().y >= WINSIZE_Y+100
				|| Battle::instance->GetPlayer()->Onhit((*e)->GetPos()))
			{
				(*e)->SetIsFire(false);
				StE_Missiles.push((*e));
				e = vecEnemyMissiles.erase(e);
				if (e == vecEnemyMissiles.end())
					break;
			}
		}
	}
}

void MissileManager::Render(HDC hdc)
{
	if ((vecEnemyMissiles.size()) > 0)
	{
		for (auto& it : vecEnemyMissiles)
		{
			it->Render(hdc);
		}
	}

	if ((vecPlayerMissiles.size()) > 0)
	{
		for (auto& it : vecPlayerMissiles)
		{
			it->Render(hdc);
		}
	}
}

bool MissileManager::Fire(float posX, float posY, float angle)
{
	EnemyMissile* E_Bullet;
	PlayerMissile* P_Bullet;

	if (isEnemy)
	{
		if (StE_Missiles.size() > 0)
		{
			E_Bullet = StE_Missiles.top();
			StE_Missiles.pop();
			vecEnemyMissiles.push_back(E_Bullet);
			for (auto& it : vecEnemyMissiles)
			{
				if (it->GetIsFire())
				{
					continue;
				}
				it->SetAngle(DEGREE_TO_RADIAN(angle));
				it->SetIsFire(true);
				it->SetPos(posX, posY);
			}
		}
	}
	else if(!isEnemy)
	{
		if (StP_Missiles.size() > 0)
		{
			P_Bullet = StP_Missiles.top();
			StP_Missiles.pop();
			vecPlayerMissiles.push_back(P_Bullet);
			for (auto& it : vecPlayerMissiles) //////// ����� 0/
			{
				if (it->GetIsFire())
				{
					continue;
				}
				it->SetIsFire(true);
				it->SetPos(posX, posY);
			}
		}
		
	}
	return true;
}



MissileManager::MissileManager()
{
}


MissileManager::~MissileManager()
{
}
