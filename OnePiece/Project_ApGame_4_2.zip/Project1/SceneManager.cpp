#include "SceneManager.h"
#include "Image.h"
#include "Battle.h"

HRESULT SceneManager::Init()
{
	selectBGImg = new Image();
	selectPointerImg = new Image();
	battle = new Battle();

	//�̹����� ���� ũ��, ���� ũ��
	width = 1500;
	height = 520;

	selectBGImg->Init("Image/test.bmp", width, height);
	selectPointerImg->Init("Image/selectPointer.bmp", 500, 560, true, RGB(0, 255, 0));
	//battle->Init();

	//pos = {0, 0};
	isSelected = false;
	sceneNum = 0;
	charNum = 0;
	return S_OK;
}

void SceneManager::Update()
{
	if (isSelected == false)
	{
		if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LEFT))
		{
			if (charNum == 0)
				charNum = 2;
			else
				charNum--;
		}
		else if ((KeyManager::GetSingleton()->IsOnceKeyDown(VK_RIGHT)))
		{
			if (charNum == 2)
				charNum = 0;
			else
				charNum++;
		}


		//rc = { center.x, 0, center.x + width, 560 }

		if ((KeyManager::GetSingleton()->IsOnceKeyDown('Z')))
		{

			//charNum = 0;
			isSelected = true;
			battle->Init(charNum);
			//battle->SetCharNum(charNum);

		}
	}

	if (isSelected == true)
	{
		battle->Update();
	}
}

void SceneManager::Release()
{
	battle->Release();
	SAFE_DELETE(battle);

	selectPointerImg->Release();
	SAFE_DELETE(selectPointerImg);

	selectBGImg->Release();
	SAFE_DELETE(selectBGImg);

}

void SceneManager::Render(HDC hdc)
{
	if (isSelected == false)
	{
		if (selectBGImg)
		{
			if (CharSelect())
			{
				selectBGImg->Render(hdc, 0, 40);
			}
		}

		if (selectPointerImg)
		{
			if (CharSelect())
			{
				selectPointerImg->Render(hdc, selectPosX[charNum] + 250, 300);
			}
		}
	}
	else
	{
		battle->Render(hdc);
	}

}

int SceneManager::CharSelect()
{
	return 1;
}
