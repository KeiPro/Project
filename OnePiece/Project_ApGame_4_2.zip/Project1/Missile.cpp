#include "Missile.h"
#include "Image.h"

HRESULT Missile::Init(int charNum)
{
	//pos = { 0, 0 };
	//speed = 300.0f;
	//currFrameX = 0;
	//currFrameY = 0;
	//angle = 0.0f;
	//radius = 0.0f;


	//testcount = 0;

	//switch (charNum)
	//{
	//case 0: //�ƿ�Ű��
	//	img = ImageMgr::GetSingleton()->AddImage("B_Missile", "Image/B_Missile.bmp", 40, 37, true, RGB(0, 0, 0));
	//	break;

	//case 1:
	//	img = ImageMgr::GetSingleton()->AddImage("B_Missile", "Image/B_Missile.bmp", 40, 37, true, RGB(0, 0, 0));
	//	break;

	//case 2:
	//	img = ImageMgr::GetSingleton()->AddImage("B_Missile", "Image/B_Missile.bmp", 40, 37, true, RGB(0, 0, 0));
	//	break;
	//}


	return S_OK;
}

void Missile::Update()
{
	//if (isFire)
	//{
	//	if (img)
	//	{
	//		if (isEnemy)
	//		{
	//			pos.x -= speed * cosf(angle) * TimeManager::GetSingleton()->GetDeltaTime();
	//			pos.y -= speed * sinf(angle) * TimeManager::GetSingleton()->GetDeltaTime();
	//		}
	//		else
	//		{
	//			pos.x += speed * cosf(angle) * TimeManager::GetSingleton()->GetDeltaTime();
	//			pos.y -= speed * sinf(angle) * TimeManager::GetSingleton()->GetDeltaTime();
	//		}
	//	}

	//}
}

void Missile::Release()
{
	//img->Release();
	//SAFE_DELETE(img);
}

void Missile::Render(HDC hdc)
{
	//if (img)
	//{
	//	img->Render(hdc, pos.x, pos.y);
	//}
}

