#include "NormalEnemy_Wapol.h"
#include "Image.h"
#include "MissileManager.h"
#include "macroFunction.h"

HRESULT NormalEnemy_Wapol::Init()
{
	pos.x = WINSIZE_X + 30.0f;
	pos.y = WINSIZE_Y / 3;

	img = ImageMgr::GetSingleton()->AddImage("NormalEnemy", "Image/wapol2.bmp", 0, 0, 1000, 300, 5, 3, true, RGB(10, 114, 108));
	isAppear = false;
	currFrameX = 0;
	currFrameY = 0;
	maxKeyFrameX = 3;
	elipsedTime = 0;
	isDamaged = false;
	fireCount = 0;
	isRender = true;
	EnemyMissileMgr = new MissileManager();
	EnemyMissileMgr->Init(true);
	return S_OK;
}

void NormalEnemy_Wapol::Release()
{
	EnemyMissileMgr->Release(true);
	SAFE_DELETE(EnemyMissileMgr);
}

void NormalEnemy_Wapol::Update()
{
	EnemyMissileMgr->Update();

	if (isDamaged == false)
	{
		if (isAppear)
		{
			if (pos.x > 0 && pos.y < 900)
			{
				pos.x += 10.0f * cosf(angle);
				pos.y -= 10.0f * sinf(angle);

				elipsedTime++;
				fireCount++;

				if (CircleCollision(pos.x, pos.y, playerPos.x, playerPos.y))
				{
					currFrameY = 1;
					myState = 1;
				}
				else
				{
					currFrameY = 0;
					myState = 0;
				}

				if (elipsedTime % 3 == 0)
				{
					currFrameX++;
					elipsedTime = 0;
				}

				if (currFrameX > maxFrameX[myState])
				{
					currFrameX = 0;
				}

				if (fireCount % 15 == 14)
				{
					EnemyMissileMgr->SetIsEnemy(true);
					EnemyMissileMgr->Fire(pos.x, pos.y, 180);
				}
			}
		}
	}
	else if(isDamaged)
	{
		pos.y -= 2.0;
		elipsedTime++;
		currFrameY = 3;
		currFrameX = 0;
		maxKeyFrameX = 0;
		if (elipsedTime == 12)
		{
			isRender = false;
		}
	}
}

void NormalEnemy_Wapol::Render(HDC hdc)
{
	if (img)
	{
		if (isRender)
		{
			if (isDamaged == false)
				img->FrameRender(hdc, pos.x - 40, pos.y - 35, currFrameX, currFrameY, 1.7f);
			else
				img->FrameRender(hdc, pos.x, pos.y, currFrameX, currFrameY, 1.7f);
		}

	}

	if (EnemyMissileMgr)
	{
		EnemyMissileMgr->Render(hdc);
	}
}

bool NormalEnemy_Wapol::OnHit(FPOINT point)
{
	float length = sqrt(pow(pos.x -point.x, 2) + pow(pos.y - point.y , 2)); // �ΰ�ü���� �Ÿ� ��
	if (length < 60)
	{
		return true;
	}
	return false;
}


