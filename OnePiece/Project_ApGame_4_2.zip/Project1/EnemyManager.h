#pragma once
#include "GameNode.h"
#include "pch.h"

class NormalEnemy_Wapol;
class EnemyManager : public GameNode
{
private:

	//0527 ���� �߰�.
	FPOINT playerPos;

	vector<NormalEnemy_Wapol*> NormalWapols;
	vector<NormalEnemy_Wapol*>::iterator Ne_iter;

	stack<NormalEnemy_Wapol*> stNormalWapols;
	float currFrame;
public:
	virtual HRESULT Init();		
	virtual void Release();		
	virtual void Update();		
	virtual void Render(HDC hdc);

	bool Onhit(FPOINT pos);

	void SetPlayerPos(FPOINT _playerPos) { playerPos = _playerPos; }
};

