#pragma once
#include "Enemy.h"
class BossEnemy : public Enemy
{
protected:


public:
	virtual HRESULT Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
};

