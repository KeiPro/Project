// macroFunction.h
#pragma once
#include "pch.h"

inline float TwoPointAngle(float x1, float y1, float x2, float y2)
{
	return atan2f(-(y2 - y1), x2 - x1);
}

inline bool CircleCollision(float x1, float y1, float x2, float y2)
{
	if (sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2)) < 40)
	{
		return true;
	}
	else
		return false;
}