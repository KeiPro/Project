#include "EliteEnemy.h"
#include "Image.h"
#include "MissileManager.h"

HRESULT EliteEnemy::Init()
{
	img = ImageMgr::GetSingleton()->AddImage("Whitebeard", "Image/Whitebeard.bmp", 0, 0, 800, 300, 4, 2, true, RGB(117, 126, 243));

	pos.x = WINSIZE_X;
	pos.y = WINSIZE_Y / 2;

	currFrameX = 0;
	currFrameY = 0;

	elipsedTime = 0;
	myState = 0;
	missileAngle = 0;

	eliteEnemyState = EliteEnemyState::IDLE;

	enemyMissile = new MissileManager();
	enemyMissile->Init(true);

	isCircle = false;
	speed = 10.0f;
	life = 1;
	isAppear = false;
	frameRate = 0;
	upState = false;
	downState = false;
	angle = 0;

	fireFrame = 0;
	fireDelay = 10;

	return S_OK;
}

void EliteEnemy::Release()
{
	enemyMissile->Release();
	SAFE_DELETE(enemyMissile);
}

void EliteEnemy::Update()
{
	if (isAppear)
	{
		frameRate++;
		fireFrame++; // fire�� Delay������ ����

		if (frameRate >= 120)
		{
			myState = 1;
			currFrameY = myState;
			upState = true;
			eliteEnemyState = EliteEnemyState::PATTERN1;
		}

		
		//if (upState == true)
		//{
		//	if (pos.y >= 50)
		//	{
		//		pos.y -= speed;
		//	}
		//	else
		//	{
		//		/*myState = 1;
		//		currFrameY = myState;*/
		//		upState = false;
		//		downState = true;
		//	}
		//}
		//else if (downState == true)
		//{
		//	if (pos.y + 100 <= WINSIZE_Y - 50)
		//	{
		//		pos.y += speed;
		//	}
		//	else
		//	{
		//		//myState = 1;
		//		//currFrameY = myState;
		//		upState = true;
		//		downState = false;
		//	}
		//}

		if (pos.x >= WINSIZE_X * 2 / 3)
		{
			pos.x -= speed;
		}

		elipsedTime++;

	/*	if (fireCount % 50 == 0)
		{
			EnemyMissileMgr->Fire(pos.x, pos.y);
		}
	*/
		if (isCircle)
		{
			angle -= 3;
		}
		else
		{
			angle += 3;
		}

		if (eliteEnemyState == EliteEnemyState::PATTERN1 && fireFrame > fireDelay)
		{
			fireFrame = 0;
			enemyMissile->SetIsEnemy(true);
			enemyMissile->Fire(pos.x, pos.y, angle);
			enemyMissile->Fire(pos.x, pos.y, angle + 90);
			enemyMissile->Fire(pos.x, pos.y, angle + 180);
			enemyMissile->Fire(pos.x, pos.y, angle + 270);
		}

		if (angle >= 90)
		{
			angle = 0;
			fireDelay--;
			if (fireDelay < 1)
			{
				fireDelay = 1;
				isCircle = true;
			}
		}
			
		enemyMissile->Update();

		switch (eliteEnemyState)
		{
		case EliteEnemyState::IDLE:

			if (elipsedTime % 5 == 0)
			{
				currFrameX++;
				elipsedTime = 0;
			}

			if (currFrameX > maxFrameX[myState])
			{
				currFrameX = 0;
			}

			break;

		case EliteEnemyState::PATTERN1:

			if (elipsedTime % 3 == 0)
			{
				currFrameX++;
				elipsedTime = 0;
			}

			if (currFrameX > maxFrameX[myState])
			{
				currFrameX = 0;
			}

			break;

		case EliteEnemyState::STAR:



			break;

		case EliteEnemyState::HEART:

			break;
		}


	}
}

void EliteEnemy::Render(HDC hdc)
{
	if (img)
	{
		img->FrameRender(hdc, pos.x, pos.y, currFrameX, currFrameY, 1.7f);
	}

	if (enemyMissile)
	{
		enemyMissile->Render(hdc);
	}
}

void EliteEnemy::Pattern1()
{
}
