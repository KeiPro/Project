#include "Battle.h"
#include "Young_airplane.h"
#include "Jong_airplane.h"
#include "Sung_airplane.h"
#include "Image.h"
#include "EnemyManager.h"
#include "Player.h"
#include "EliteEnemy.h"

Battle* Battle::instance = 0;

HRESULT Battle::Init(int selectIdx)
{
	instance = this;
	backgroundImg = ImageMgr::GetSingleton()->AddImage("backgroundImg", "Image/Background.bmp", WINSIZE_X, WINSIZE_Y, false);

	charNum = selectIdx;
	sourceX = 0;

	enemyMgr = new EnemyManager();
	enemyMgr->Init();

	eliteEnemy = new EliteEnemy();
	eliteEnemy->Init();
	eliteEnemy->SetIsAppear(true);

	 player = new Player();
	player->Init(charNum);
	return S_OK;
}

void Battle::Update()
{
	player->Update();
	//WINSIZE_X���� ���� ���, 0���� ����.
	sourceX++;
	if (sourceX > WINSIZE_X)
	{
		sourceX = 0;
	}

	if (enemyMgr)
	{
		enemyMgr->SetPlayerPos(player->GetPlayerPos());
		enemyMgr->Update();
	}

	if (eliteEnemy)
	{
		eliteEnemy->Update();
	}
}

void Battle::Release()
{
	if (eliteEnemy)
	{
		eliteEnemy->Release();
		SAFE_DELETE(eliteEnemy);
	}

	if (enemyMgr)
	{
		enemyMgr->Release();
		SAFE_DELETE(enemyMgr);
	}

	if (player)
	{
		player->Release();
		SAFE_DELETE(player);
	}
}

void Battle::Render(HDC hdc)
{
	if (backgroundImg)
	{
		backgroundImg->Render(hdc, 0, 0, sourceX, 0);
	}

	if (player)
	{
		player->Render(hdc);
	}

	if (enemyMgr)
	{
		enemyMgr->Render(hdc);
	}

	if (eliteEnemy)
	{
		eliteEnemy->Render(hdc);
	}

}

FPOINT Battle::GetPlayerPos()
{
	return player->GetPos();
}
