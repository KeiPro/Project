#pragma once
#include "Object.h"
class Enemy : public Object
{
protected:


public:
	virtual HRESULT Init();
	virtual void Release();
	virtual void Update();
	virtual void Render(HDC hdc);
};

