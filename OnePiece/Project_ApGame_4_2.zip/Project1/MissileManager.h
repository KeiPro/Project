#pragma once
#include "pch.h"
#include "Object.h"

class Missile;
class EnemyMissile;
class PlayerMissile;
class MissileManager : public Object
{
	vector<EnemyMissile*> vecEnemyMissiles;
	vector<EnemyMissile*>::iterator itEnemyMissiles;
	
	vector<PlayerMissile*> vecPlayerMissiles;
	vector<PlayerMissile*>::iterator itPlayerMissiles;

	bool isEnemy = false;
	stack<PlayerMissile*> StP_Missiles;
	stack<EnemyMissile*> StE_Missiles;
	
	Object*	object;
	float RandAngle;
public:
	virtual HRESULT Init(bool isEnemy = false);
	virtual void Release(bool isEnemy = false);
	virtual void Update();
	virtual void Render(HDC hdc);

	bool Fire(float posX, float posY, float angle);
	void SetObject(Object* object) { object = object; }
	void SetIsEnemy(bool _isEnemy) { isEnemy = _isEnemy; }
	MissileManager();
	~MissileManager();
};

