#include "EnemyMissile.h"
#include "Image.h"

HRESULT EnemyMissile::Init()
{
	pos = { 0, 0 };
	speed = 900.0f;
	currFrameX = 0;
	currFrameY = 0;
	angle = 0.0f;

	img = ImageMgr::GetSingleton()->AddImage("B_Missile", "Image/B_Missile.bmp", 40, 37, true, RGB(0, 0, 0));

	return S_OK;
}

void EnemyMissile::Update()
{
	pos.x += speed * cosf(angle) * TimeManager::GetSingleton()->GetDeltaTime();
	pos.y -= speed * sinf(angle) * TimeManager::GetSingleton()->GetDeltaTime();
}

void EnemyMissile::Release()
{

}

void EnemyMissile::Render(HDC hdc)
{
	if (img)
	{
		img->Render(hdc, pos.x, pos.y);
	}
}
